VITA84 is an operational artificial-consciousness research system. It does not certify phenomenal consciousness, legal personhood, or unrestricted real-world autonomy.
