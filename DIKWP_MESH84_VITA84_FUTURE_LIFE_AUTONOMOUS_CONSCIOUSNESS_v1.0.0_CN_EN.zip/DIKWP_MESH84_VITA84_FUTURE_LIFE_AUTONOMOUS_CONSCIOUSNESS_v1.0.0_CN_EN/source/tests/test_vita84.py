
from vita84.selftest import run

def test_all():
    r=run(); assert r['passed'], r
