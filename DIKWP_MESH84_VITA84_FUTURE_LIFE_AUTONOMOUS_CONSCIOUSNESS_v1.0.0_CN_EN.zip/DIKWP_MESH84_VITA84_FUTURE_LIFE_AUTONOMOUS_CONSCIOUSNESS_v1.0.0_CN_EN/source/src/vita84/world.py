
from __future__ import annotations
from pathlib import Path
from .util import read_json, write_json

class World:
    def __init__(self,workspace:Path): self.workspace=Path(workspace); self.path=self.workspace/'world.json'
    def load(self): return read_json(self.path,{'world_id':'EMPTY','title_cn':'空世界','tick':0,'resources':{},'entities':[],'events':[]})
    def install(self,src:Path):
        obj=read_json(Path(src)); write_json(self.path,obj); return obj
    def add_event(self,event):
        w=self.load(); w.setdefault('events',[]).append(event); w['tick']=int(w.get('tick',0))+1; write_json(self.path,w); return w
