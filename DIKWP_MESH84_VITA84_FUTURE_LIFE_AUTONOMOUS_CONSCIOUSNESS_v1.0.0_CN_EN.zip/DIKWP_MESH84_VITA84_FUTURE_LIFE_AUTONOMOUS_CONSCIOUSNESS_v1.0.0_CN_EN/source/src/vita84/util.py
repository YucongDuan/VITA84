
from __future__ import annotations
import json, hashlib, os, re
from pathlib import Path
from datetime import datetime, timezone
from typing import Any

def now_iso()->str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace('+00:00','Z')

def canonical(obj:Any)->bytes:
    return json.dumps(obj,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode('utf-8')

def digest(obj:Any)->str:
    return hashlib.sha256(canonical(obj)).hexdigest()

def read_json(path:Path, default=None):
    if not path.exists(): return default
    return json.loads(path.read_text(encoding='utf-8'))

def write_json(path:Path,obj:Any):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding='utf-8')

def safe_name(s:str)->str:
    return re.sub(r'[^A-Za-z0-9._-]+','_',s)[:100]
