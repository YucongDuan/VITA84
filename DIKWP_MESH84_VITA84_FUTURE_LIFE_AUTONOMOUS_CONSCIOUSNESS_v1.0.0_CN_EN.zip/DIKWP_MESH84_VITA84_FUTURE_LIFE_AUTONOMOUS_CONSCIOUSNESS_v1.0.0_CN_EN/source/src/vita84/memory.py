
from __future__ import annotations
from pathlib import Path
from .ledger import Ledger

class Memory:
    def __init__(self,workspace:Path): self.workspace=Path(workspace); self.ledger=Ledger(self.workspace/'memory.jsonl')
    def remember(self,kind,content,semantic_kind='D',salience=0.5,private=False,refs=None):
        return self.ledger.append({'type':'memory','memory_kind':kind,'semantic_kind':semantic_kind,'content':content,'salience':salience,'private':private,'refs':refs or []})
    def recent(self,n=20,public_only=False):
        rows=[r for r in self.ledger.rows() if r.get('type')=='memory']
        if public_only: rows=[r for r in rows if not r.get('private')]
        return rows[-n:]
    def search(self,terms,n=10):
        ts=[t.lower() for t in terms.split() if t.strip()]
        scored=[]
        for r in self.recent(500):
            text=str(r.get('content','')).lower(); score=sum(text.count(t) for t in ts)+float(r.get('salience',0))
            if score: scored.append((score,r))
        return [r for _,r in sorted(scored,key=lambda x:(-x[0],-x[1]['seq']))[:n]]
