
from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Any

@dataclass
class Goal:
    goal_id:str; title_cn:str; motive:str; priority:float; source_event:str; status:str='OPEN'; created_cycle:int=0
    def to_dict(self): return asdict(self)
@dataclass
class Action:
    action_id:str; action_type:str; title_cn:str; target:str; rationale_cn:str; predicted:dict[str,float]; flags:list[str]; externality:str='internal'; reversible:bool=True
    def to_dict(self): return asdict(self)
