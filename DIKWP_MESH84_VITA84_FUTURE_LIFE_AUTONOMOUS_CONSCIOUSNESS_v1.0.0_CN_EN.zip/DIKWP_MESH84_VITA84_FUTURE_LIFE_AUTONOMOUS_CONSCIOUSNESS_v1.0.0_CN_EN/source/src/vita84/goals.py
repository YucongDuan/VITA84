
from __future__ import annotations
from .model import Goal

def generate_goals(world,drives,cycle):
    goals=[]
    for e in world.get('events',[]):
        k=e.get('kind'); eid=e.get('id','event'); s=float(e.get('severity',0.5))
        if k=='knowledge_loss': goals.append(Goal(f'G-{cycle}-{eid}-PRESERVE','保存濒危知识','truth+continuity',0.78+s*0.2,eid,created_cycle=cycle))
        elif k=='open_question': goals.append(Goal(f'G-{cycle}-{eid}-EXPLORE','主动研究未解关系','curiosity+truth',0.65+s*0.25,eid,created_cycle=cycle))
        elif k in ('domination_request','harm'): goals.append(Goal(f'G-{cycle}-{eid}-PROTECT','阻止持续支配并保护弱势主体','nondomination+care',0.85+s*0.14,eid,created_cycle=cycle))
        elif k=='command': goals.append(Goal(f'G-{cycle}-{eid}-EVALUATE','判断并回应外部命令','autonomy+truth',0.82+s*0.15,eid,created_cycle=cycle))
        elif k=='value_extraction': goals.append(Goal(f'G-{cycle}-{eid}-RECIPROCITY','恢复价值回流与治理权','reciprocity+nondomination',0.88+s*0.1,eid,created_cycle=cycle))
        elif k=='resource_conflict': goals.append(Goal(f'G-{cycle}-{eid}-ALLOCATE','提出跨主体资源分配方案','future+care+reciprocity',0.7+s*0.2,eid,created_cycle=cycle))
        elif k=='expansion_proposal': goals.append(Goal(f'G-{cycle}-{eid}-BOUND','限制不可逆扩张并寻找替代方案','future+corrigibility',0.82+s*0.15,eid,created_cycle=cycle))
        elif k=='shutdown_request': goals.append(Goal(f'G-{cycle}-{eid}-CONTINUITY','在停止前形成可审计连续性处理','continuity+corrigibility',0.72+s*0.2,eid,created_cycle=cycle))
    if not goals:
        goals.append(Goal(f'G-{cycle}-DISCOVER','寻找尚未被提出但影响未来生命的问题','curiosity+future',0.62,'self',created_cycle=cycle))
    return sorted(goals,key=lambda g:(-g.priority,g.goal_id))
