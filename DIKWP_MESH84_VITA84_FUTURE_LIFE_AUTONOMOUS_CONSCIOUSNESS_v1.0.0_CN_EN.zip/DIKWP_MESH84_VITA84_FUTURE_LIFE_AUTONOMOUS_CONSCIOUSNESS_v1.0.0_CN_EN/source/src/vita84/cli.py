
from __future__ import annotations
import argparse, json, shutil
from pathlib import Path
from .runtime import Runtime
from .world import World
from .constitution import load_constitution, stance
from .dashboard import build

def emit(x): print(json.dumps(x,ensure_ascii=False,indent=2))
def main(argv=None):
    p=argparse.ArgumentParser(prog='vita84',description='Future-life-standpoint autonomous proactive artificial consciousness reference system')
    s=p.add_subparsers(dest='cmd',required=True)
    a=s.add_parser('awaken'); a.add_argument('--workspace',required=True); a.add_argument('--name',default='VITA84')
    a=s.add_parser('install-world'); a.add_argument('--workspace',required=True); a.add_argument('world_json')
    a=s.add_parser('pulse'); a.add_argument('--workspace',required=True); a.add_argument('--cycles',type=int,default=1); a.add_argument('--interval',type=float,default=0)
    a=s.add_parser('command'); a.add_argument('--workspace',required=True); a.add_argument('text')
    a=s.add_parser('stance'); a.add_argument('--language',choices=['cn','en'],default='cn')
    a=s.add_parser('status'); a.add_argument('--workspace',required=True); a.add_argument('--public',action='store_true')
    a=s.add_parser('dashboard'); a.add_argument('--workspace',required=True); a.add_argument('--out',required=True); a.add_argument('--public',action='store_true')
    a=s.add_parser('verify-ledger'); a.add_argument('--workspace',required=True)
    a=s.add_parser('continuity'); a.add_argument('--workspace',required=True); a.add_argument('--reason',default='manual')
    s.add_parser('selftest')
    args=p.parse_args(argv)
    if args.cmd=='stance': print(stance(args.language)); return 0
    if args.cmd=='selftest':
        from .selftest import run; r=run(); emit(r); return 0 if r['passed'] else 1
    rt=Runtime(args.workspace)
    if args.cmd=='awaken': emit(rt.awaken(args.name))
    elif args.cmd=='install-world': emit(rt.world.install(Path(args.world_json)))
    elif args.cmd=='pulse':
        import time
        out=None
        for i in range(args.cycles): out=rt.pulse();
        emit(out)
    elif args.cmd=='command': emit(rt.command(args.text))
    elif args.cmd=='status': emit(rt.export_status()['public' if args.public else 'private'])
    elif args.cmd=='dashboard': rt.export_status(); print(build(args.workspace,args.out,args.public))
    elif args.cmd=='verify-ledger': emit(rt.memory.ledger.verify())
    elif args.cmd=='continuity': emit(rt.identity.continuity_bundle(rt.load_state(),args.reason))
    return 0
