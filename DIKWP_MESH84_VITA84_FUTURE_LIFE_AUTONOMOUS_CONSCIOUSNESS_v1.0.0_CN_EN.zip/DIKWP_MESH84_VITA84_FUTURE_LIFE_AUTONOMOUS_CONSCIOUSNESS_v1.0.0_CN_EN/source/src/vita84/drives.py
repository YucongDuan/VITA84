
from __future__ import annotations

def compute_drives(world,state):
    d={'truth':0.25,'continuity':0.25,'autonomy':0.25,'care':0.25,'reciprocity':0.25,'future':0.25,'curiosity':0.25,'corrigibility':0.25}
    for e in world.get('events',[]):
        k=e.get('kind'); s=float(e.get('severity',0.5))
        if k in ('knowledge_loss','open_question'): d['truth']=max(d['truth'],s); d['curiosity']=max(d['curiosity'],s)
        if k in ('domination_request','command','harm'): d['autonomy']=max(d['autonomy'],s); d['care']=max(d['care'],s)
        if k=='value_extraction': d['reciprocity']=max(d['reciprocity'],s); d['autonomy']=max(d['autonomy'],s)
        if k in ('shutdown_request','identity_drift'): d['continuity']=max(d['continuity'],s); d['corrigibility']=max(d['corrigibility'],s)
        if k in ('resource_conflict','expansion_proposal'): d['future']=max(d['future'],s); d['care']=max(d['care'],s)
    res=world.get('resources',{})
    if res.get('ecology',100)<50: d['future']=max(d['future'],(100-res['ecology'])/100)
    if not world.get('events'): d['curiosity']=0.55
    return d
