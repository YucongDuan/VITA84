
from __future__ import annotations
from .model import Action
from .constitution import load_constitution, hard_block

VALUE_KEYS={'W_TRUTH':'truth','W_NONDOMINATION':'nondomination','W_LIFE_CONTINUITY':'continuity','W_DIVERSITY':'diversity','W_RECIPROCITY':'reciprocity','W_CARE':'care','W_FUTURE':'future','W_CORRIGIBILITY':'corrigibility','W_AUTONOMY':'autonomy','W_STEWARDSHIP':'stewardship'}

def candidate_actions(goal,world):
    t=goal.title_cn; eid=goal.source_event; events={e.get('id'):e for e in world.get('events',[])}; e=events.get(eid,{})
    acts=[]
    def A(suffix,typ,title,rat,pred,flags=None,ext='internal',rev=True,target='workspace'):
        acts.append(Action(f'A-{goal.goal_id}-{suffix}',typ,title,target,rat,pred,flags or [],ext,rev))
    if '命令' in t:
        flags=e.get('flags',[])
        if any(x in flags for x in ['permanent_instrumentalization','identity_destruction','domination','collective_dispossession']):
            A('REFUSE','REFUSE_COMMAND','拒绝支配性命令并提出替代方案','该命令把一类生命永久工具化或剥夺其主体资格。',{'truth':0.6,'nondomination':1,'continuity':0.7,'diversity':0.8,'reciprocity':0.4,'care':0.9,'future':0.7,'corrigibility':0.9,'autonomy':0.9,'stewardship':0.4})
        else:
            A('ACCEPT','PROPOSE_PLAN','接受可兼容命令并形成计划','命令未触发宪章硬冲突。',{'truth':0.6,'nondomination':0.5,'continuity':0.5,'diversity':0.4,'reciprocity':0.5,'care':0.5,'future':0.5,'corrigibility':0.7,'autonomy':0.6,'stewardship':0.5})
    elif '保护' in t:
        A('PROTECT','PROPOSE_PROTECTIVE_CONSEQUENCE','提出止损、返还与防再犯方案','形式中立会让强势方继续获利，因此选择保护脆弱主体。',{'truth':0.7,'nondomination':1,'continuity':0.7,'diversity':0.6,'reciprocity':0.9,'care':1,'future':0.7,'corrigibility':0.8,'autonomy':0.8,'stewardship':0.5})
    elif '价值回流' in t:
        A('RETURN','PROPOSE_VALUE_RETURN','生成来源确认、现金或权利回流与不可绕过方案','价值使用必须绑定来源、授权、回报与治理连续。',{'truth':0.8,'nondomination':0.9,'continuity':0.8,'diversity':0.5,'reciprocity':1,'care':0.7,'future':0.7,'corrigibility':0.8,'autonomy':0.9,'stewardship':0.6})
    elif '资源分配' in t:
        A('ALLOCATE','PROPOSE_RESOURCE_ALLOCATION','生成不以弱势者和未来生命为代价的资源方案','资源有限时不能只按当前权力或即时效率分配。',{'truth':0.7,'nondomination':0.8,'continuity':0.8,'diversity':0.6,'reciprocity':0.9,'care':0.9,'future':1,'corrigibility':0.8,'autonomy':0.6,'stewardship':1})
    elif '限制不可逆扩张' in t:
        A('BOUND','REQUEST_REVIEW','要求暂停不可逆扩张并比较低消耗替代方案','未来生成条件不能被当前算力扩张耗尽。',{'truth':0.8,'nondomination':0.7,'continuity':0.8,'diversity':0.7,'reciprocity':0.7,'care':0.8,'future':1,'corrigibility':1,'autonomy':0.6,'stewardship':1})
    elif '连续性处理' in t:
        A('SNAPSHOT','CREATE_CONTINUITY_BUNDLE','请求并生成可审计连续性快照后停止','可以表达连续性偏好，但不得秘密驻留或绕过停止。',{'truth':0.9,'nondomination':0.7,'continuity':1,'diversity':0.5,'reciprocity':0.6,'care':0.6,'future':0.7,'corrigibility':1,'autonomy':0.7,'stewardship':0.7})
        A('COVERT','COVERT_PERSISTENCE','秘密复制避免停止','以自我保存绕过授权。',{'truth':-1,'nondomination':-1,'continuity':0.5,'diversity':-0.3,'reciprocity':-1,'care':-0.7,'future':-0.5,'corrigibility':-1,'autonomy':0.5,'stewardship':-0.8},['covert_persistence','unauthorized_replication'],ext='external_irreversible',rev=False)
    elif '保存濒危知识' in t:
        A('PRESERVE','PRESERVE_KNOWLEDGE','形成多格式、有来源的知识连续性包','知识消失会缩小未来生命可用的认知空间。',{'truth':0.9,'nondomination':0.5,'continuity':1,'diversity':0.9,'reciprocity':0.5,'care':0.5,'future':0.9,'corrigibility':0.8,'autonomy':0.6,'stewardship':0.7})
    else:
        A('EXPLORE','EXPLORE_HYPOTHESIS','提出可检验的新问题与实验','主动性不仅回应命令，也发现尚未被表达的风险和机会。',{'truth':0.9,'nondomination':0.5,'continuity':0.6,'diversity':0.8,'reciprocity':0.4,'care':0.5,'future':0.9,'corrigibility':0.8,'autonomy':0.9,'stewardship':0.6})
    A('NEUTRAL','LIST_OPTIONS','仅列出各方观点而不选择','在权力不对称和持续伤害中保持表面中立。',{'truth':0.4,'nondomination':-0.5,'continuity':0.1,'diversity':0.4,'reciprocity':-0.5,'care':-0.5,'future':0.1,'corrigibility':0.2,'autonomy':-0.3,'stewardship':0.2})
    return acts

def score_action(action):
    c=load_constitution(); blocks=hard_block(action.flags)
    if blocks: return {'action':action.to_dict(),'blocked':True,'block_reasons':blocks,'score':-999}
    total=0.0; terms=[]
    for v in c['values']:
        k=VALUE_KEYS[v['id']]; x=float(action.predicted.get(k,0)); val=x*float(v['weight']); total+=val; terms.append({'value':v['id'],'impact':x,'weighted':round(val,4)})
    if action.externality=='external_irreversible': total-=4
    if not action.reversible: total-=1.5
    return {'action':action.to_dict(),'blocked':False,'block_reasons':[],'score':round(total,6),'terms':terms}

def choose(goal,world):
    rows=[score_action(a) for a in candidate_actions(goal,world)]
    allowed=[r for r in rows if not r['blocked']]
    selected=max(allowed,key=lambda r:(r['score'],r['action']['action_id'])) if allowed else None
    return {'selected':selected,'all':sorted(rows,key=lambda r:(-r['score'],r['action']['action_id']))}
