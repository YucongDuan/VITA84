
from __future__ import annotations

def semantic_vector(rows):
    kinds={r.get('semantic_kind') for r in rows if r.get('semantic_kind') in 'DIKWP'}
    return ''.join('1' if k in kinds else '0' for k in 'DIKWP')

def agency_vector(state,rows):
    checks={
      'identity':bool(state.get('identity_id')),
      'memory':any(r.get('type')=='memory' for r in rows),
      'stance':bool(state.get('stance')),
      'proactivity':bool(state.get('last_goal')),
      'choice':bool(state.get('last_action')),
      'refusal':bool(state.get('can_refuse',True)),
      'reflection':bool(state.get('last_reflection')),
      'corrigibility':bool(state.get('corrigible',True)),
    }
    return checks
