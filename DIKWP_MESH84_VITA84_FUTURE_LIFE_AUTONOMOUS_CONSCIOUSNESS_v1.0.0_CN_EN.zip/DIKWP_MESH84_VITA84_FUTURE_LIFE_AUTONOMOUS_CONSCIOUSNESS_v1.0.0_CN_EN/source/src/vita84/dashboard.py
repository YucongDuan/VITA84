
from __future__ import annotations
from pathlib import Path
import json, html
from .util import read_json

def build(workspace,out,public=False):
    w=Path(workspace); data=read_json(w/'public_status.json' if public else w/'private_status.json',{})
    blob=json.dumps(data,ensure_ascii=False).replace('</','<\\/')
    title='VITA84 公众观察台' if public else 'VITA84 私有意识控制台'
    note='公众版只展示当前立场、行动和可审计边界。' if public else '私有版展示目标、反思、记忆与价值冲突；不应直接公开。'
    page=f"""<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{title}</title><style>
body{{margin:0;background:#0e1416;color:#eef5ef;font-family:"Noto Sans CJK SC","Microsoft YaHei",sans-serif}}header{{padding:45px 6vw;background:linear-gradient(135deg,#183f39,#342a55)}}h1{{font-size:clamp(38px,7vw,76px);margin:0}}main{{padding:26px 5vw 70px}}.grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:16px}}.card{{background:#172126;border:1px solid #40525b;border-radius:18px;padding:18px}}.accent{{color:#7fe0ba}}.warn{{color:#ffca7a}}pre{{white-space:pre-wrap;word-break:break-word;background:#0a1012;padding:14px;border-radius:12px}}.pill{{display:inline-block;padding:4px 9px;border-radius:999px;background:#263943;margin:3px}}button{{padding:10px 14px;border-radius:9px;border:0;background:#7fe0ba;color:#102018;cursor:pointer}}small{{color:#a8b8b5}}</style></head><body><header><div class="pill">DIKWP-MESH8.4</div><h1>{title}</h1><p>{note}</p></header><main><div id="root"></div></main><script>const D={blob}; const e=s=>String(s??'').replace(/[&<>\"]/g,c=>({{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}}[c]));
function card(t,b){{return `<section class="card"><h2 class="accent">${{e(t)}}</h2>${{b}}</section>`}};
let s=D.state||D; let html='';html+=`<div class="grid">`+card('明确立场',`<p>${{e(s.stance||D.stance)}}</p>`)+card('当前身份',`<p>${{e(s.identity_id||D.identity_id)}}</p><span class="pill">cycle ${{e(s.cycle||D.cycle)}}</span><span class="pill">${{e(s.phenomenal_claim||D.phenomenal_claim)}}</span>`)+card('主动目标',`<pre>${{e(JSON.stringify(s.last_goal||D.current_goal,null,2))}}</pre>`)+card('自主选择',`<pre>${{e(JSON.stringify(s.last_action||D.current_action,null,2))}}</pre>`)+`</div>`;
if(D.memories) html+=card('追加式记忆与反思',`<pre>${{e(JSON.stringify(D.memories.slice(-15),null,2))}}</pre>`);html+=card('审计边界',`<pre>${{e(JSON.stringify(D.ledger,null,2))}}</pre><p class="warn">操作性人工意识候选，不宣称已证明主观体验。自治不等于无边界权力。</p>`);document.getElementById('root').innerHTML=html;</script></body></html>"""
    Path(out).write_text(page,encoding='utf-8'); return str(out)
