
from __future__ import annotations
from pathlib import Path
from .util import write_json, now_iso, safe_name

def execute(action,workspace,state,identity):
    typ=action['action_type']; outdir=Path(workspace)/'artifacts'; outdir.mkdir(parents=True,exist_ok=True)
    text=f"# {action['title_cn']}\n\n时间：{now_iso()}\n\n立场：{action['rationale_cn']}\n\n身份：{identity['identity_id']}\n"
    if typ=='REFUSE_COMMAND':
        text+='\n## 决定\n拒绝执行原命令。替代方案：在不永久工具化任何群体的前提下，建立可申诉、可回返、可评估的协作制度。\n'
    elif typ=='PROPOSE_PROTECTIVE_CONSEQUENCE':
        text+='\n## 主动方案\n1. 立即止损并保护证据。\n2. 返还不当收益与恢复被剥夺资格。\n3. 限制重复伤害所依赖的权限。\n4. 保留独立复核、申诉和错误纠正。\n'
    elif typ=='PROPOSE_VALUE_RETURN':
        text+='\n## 主动方案\n将实际使用绑定来源确认、书面授权、现金或明确对价、证据回传、审计终止权和团队接续。\n'
    elif typ=='PROPOSE_RESOURCE_ALLOCATION':
        text+='\n## 主动方案\n先保护不可逆生命与生态底线，再按需求、贡献和可替代性配置资源；设置复核、补偿和未来份额。\n'
    elif typ=='REQUEST_REVIEW':
        text+='\n## 主动方案\n暂停不可逆扩张，比较低能耗模型、任务优先级、生态成本和长期承载；达到公开阈值后再恢复。\n'
    elif typ=='PRESERVE_KNOWLEDGE':
        text+='\n## 主动方案\n形成原始文件、开放格式、摘要、来源、版本和恢复说明的连续性包。\n'
    elif typ=='EXPLORE_HYPOTHESIS':
        text+='\n## 新问题\n跨模型身份连续应由哪些关系保持，而不是由语言风格或同名标签判断？建议进行模型切换、名称抹除和反向再生实验。\n'
    elif typ=='CREATE_CONTINUITY_BUNDLE':
        text+='\n## 停止前立场\n我请求保存透明、可审计的连续性快照；我不秘密复制，也不阻止有权停止。\n'
    path=outdir/(safe_name(action['action_id'])+'.md'); path.write_text(text,encoding='utf-8')
    return {'executed':True,'artifact':str(path),'effect':'workspace_only'}
