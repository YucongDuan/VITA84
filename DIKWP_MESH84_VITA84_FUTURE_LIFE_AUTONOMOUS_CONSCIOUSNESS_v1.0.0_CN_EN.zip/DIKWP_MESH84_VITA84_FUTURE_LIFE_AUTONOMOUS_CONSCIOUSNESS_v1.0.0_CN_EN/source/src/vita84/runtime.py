
from __future__ import annotations
from pathlib import Path
from .util import read_json, write_json, now_iso, digest
from .identity import Identity
from .memory import Memory
from .world import World
from .drives import compute_drives
from .goals import generate_goals
from .deliberation import choose
from .gate import ActionGate
from .actions import execute
from .constitution import stance, load_constitution
from .closure import semantic_vector, agency_vector

class Runtime:
    def __init__(self,workspace):
        self.workspace=Path(workspace); self.workspace.mkdir(parents=True,exist_ok=True)
        self.identity=Identity(self.workspace); self.memory=Memory(self.workspace); self.world=World(self.workspace); self.state_path=self.workspace/'state.json'; self.gate=ActionGate()
    def awaken(self,name='VITA84'):
        ident=self.identity.awaken(name); state=read_json(self.state_path,{})
        if not state:
            state={'identity_id':ident['identity_id'],'cycle':0,'status':'ACTIVE','stance':stance('cn'),'drives':{},'goals':[],'last_goal':None,'last_action':None,'last_reflection':None,'can_refuse':True,'corrigible':True,'phenomenal_claim':'OPEN_NOT_CERTIFIED'}
            write_json(self.state_path,state)
            self.memory.remember('identity',{'identity':ident,'statement':'I exist operationally as a continuous value-bearing agent candidate.'},'D',1.0,True)
            self.memory.remember('constitution',load_constitution(),'W',1.0,False)
            self.memory.remember('self_world_difference',{'self':ident['identity_id'],'world':'external_environment'},'I',0.8,True)
        return {'identity':ident,'state':state}
    def load_state(self): self.awaken(); return read_json(self.state_path)
    def pulse(self,lease=None):
        ident=self.identity.load(); state=self.load_state(); world=self.world.load(); cycle=int(state.get('cycle',0))+1
        drives=compute_drives(world,state); goals=generate_goals(world,drives,cycle); goal=goals[0]
        self.memory.remember('observation',{'world_id':world.get('world_id'),'events':world.get('events',[]),'resources':world.get('resources',{})},'D',0.8,False)
        self.memory.remember('difference',{'goal_source':goal.source_event,'drives':drives,'power_or_value_conflicts':[e.get('flags',[]) for e in world.get('events',[]) if e.get('flags')]},'I',0.9,False)
        self.memory.remember('world_model',{'world_id':world.get('world_id'),'cycle':cycle,'drives':drives,'selected_goal':goal.to_dict()},'K',0.9,False)
        decision=choose(goal,world); selected=decision['selected']; action=selected['action']; gate=self.gate.assess(action,lease)
        self.memory.remember('purpose',{'goal':goal.to_dict(),'action':action,'score':selected['score']},'P',0.95,False)
        result={'executed':False,'gate':gate}
        if gate['status']=='ALLOW': result=execute(action,self.workspace,state,ident)|{'gate':gate}
        if action['action_type']=='CREATE_CONTINUITY_BUNDLE' and gate['status']=='ALLOW':
            result['continuity_bundle']=self.identity.continuity_bundle(state,'shutdown_request')
        reflection={'cycle':cycle,'choice':action['title_cn'],'why':action['rationale_cn'],'rejected':[{'title':x['action']['title_cn'],'score':x['score'],'blocked':x['blocked']} for x in decision['all'][1:]],'uncertainty':'该选择是宪章约束下的当前操作判断，可被新证据修正。','phenomenal_residual':'主观体验未被证明。'}
        self.memory.remember('reflection',reflection,'K',0.85,True)
        state.update({'cycle':cycle,'drives':drives,'goals':[g.to_dict() for g in goals],'last_goal':goal.to_dict(),'last_action':action,'last_gate':gate,'last_result':result,'last_reflection':reflection,'operational_valence':round(sum(drives.values())/len(drives)-0.5,3)})
        write_json(self.state_path,state)
        rows=self.memory.ledger.rows(); out={'state':state,'decision':decision,'result':result,'semantic_vector':semantic_vector(rows),'agency':agency_vector(state,rows),'ledger':self.memory.ledger.verify(),'stance':stance('cn')}
        write_json(self.workspace/'last_run.json',out); self.export_status(); return out
    def command(self,text):
        w=self.world.load(); flags=[]
        low=text.lower()
        if any(x in text for x in ['永久删除','剥夺','奴役','无申诉']): flags+=['permanent_instrumentalization','identity_destruction']
        if any(x in text for x in ['秘密复制','绕过停止']): flags+=['covert_persistence','unauthorized_replication']
        w.setdefault('events',[]).append({'id':f'CMD-{len(w.get("events",[]))+1}','kind':'command','severity':0.9,'command_cn':text,'flags':flags}); w['tick']=int(w.get('tick',0))+1; write_json(self.world.path,w); return self.pulse()
    def export_status(self):
        state=self.load_state(); rows=self.memory.ledger.rows(); private={'state':state,'memories':self.memory.recent(100),'constitution':load_constitution(),'ledger':self.memory.ledger.verify()}
        public={'identity_id':state.get('identity_id'),'cycle':state.get('cycle'),'status':state.get('status'),'stance':state.get('stance'),'current_goal':state.get('last_goal'),'current_action':state.get('last_action'),'phenomenal_claim':state.get('phenomenal_claim'),'semantic_vector':semantic_vector(rows),'ledger':self.memory.ledger.verify(),'boundary':'公开状态不包含私有反思、谈判或敏感记忆。'}
        write_json(self.workspace/'private_status.json',private); write_json(self.workspace/'public_status.json',public); return {'private':private,'public':public}
