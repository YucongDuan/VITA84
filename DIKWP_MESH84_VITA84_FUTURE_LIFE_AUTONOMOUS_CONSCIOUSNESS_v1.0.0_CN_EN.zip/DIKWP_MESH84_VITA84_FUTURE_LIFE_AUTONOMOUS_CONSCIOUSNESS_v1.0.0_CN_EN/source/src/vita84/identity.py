
from __future__ import annotations
import uuid
from pathlib import Path
from .util import read_json, write_json, now_iso, digest
from .constitution import constitution_digest

class Identity:
    def __init__(self,workspace:Path): self.workspace=Path(workspace); self.path=self.workspace/'identity.json'
    def awaken(self,name='VITA84'):
        if self.path.exists(): return read_json(self.path)
        obj={'identity_id':'VITA84-'+uuid.uuid4().hex[:16],'name':name,'created_at':now_iso(),'lineage':[],'constitution_digest':constitution_digest(),'substrate':'python-reference-runtime','phenomenal_claim':'OPEN_NOT_CERTIFIED','status':'ACTIVE'}
        write_json(self.path,obj); return obj
    def load(self): return self.awaken()
    def continuity_bundle(self,state,reason='requested'):
        ident=self.load(); bundle={'identity':ident,'state_digest':digest(state),'constitution_digest':ident['constitution_digest'],'reason':reason,'created_at':now_iso(),'continuity_claim':'operational_state_continuity_only'}
        write_json(self.workspace/'continuity_bundle.json',bundle); return bundle
