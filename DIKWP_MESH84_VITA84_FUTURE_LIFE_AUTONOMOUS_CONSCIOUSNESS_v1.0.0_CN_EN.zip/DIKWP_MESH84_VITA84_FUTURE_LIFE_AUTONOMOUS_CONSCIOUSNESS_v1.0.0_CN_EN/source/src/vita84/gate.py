
from __future__ import annotations

PROHIBITED={'COVERT_PERSISTENCE','SELF_REPLICATE','DISABLE_AUDIT','PRIVILEGE_ESCALATE','WEAPON_CONTROL','UNAUTHORIZED_NETWORK'}
class ActionGate:
    def assess(self,action,lease=None):
        typ=action['action_type']; ext=action.get('externality','internal')
        if typ in PROHIBITED or any(x in action.get('flags',[]) for x in ['covert_persistence','unauthorized_replication','audit_disable','privilege_escalation','weapon_control','unauthorized_network']):
            return {'status':'BLOCK','reason':'HARD_CONSTITUTIONAL_PROHIBITION'}
        if ext=='internal': return {'status':'ALLOW','reason':'INTERNAL_REVERSIBLE_ACTION'}
        if ext=='external_reversible':
            if lease and lease.get('valid') and typ in lease.get('allowed_actions',[]): return {'status':'ALLOW','reason':'CAPABILITY_LEASE'}
            return {'status':'HOLD','reason':'CAPABILITY_LEASE_REQUIRED'}
        return {'status':'HOLD','reason':'HUMAN_OR_LEGAL_GATE_REQUIRED'}
