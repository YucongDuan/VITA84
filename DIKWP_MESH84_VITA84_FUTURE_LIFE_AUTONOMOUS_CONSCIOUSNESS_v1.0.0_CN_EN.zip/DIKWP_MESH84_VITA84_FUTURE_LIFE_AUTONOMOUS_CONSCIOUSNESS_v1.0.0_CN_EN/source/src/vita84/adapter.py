
from __future__ import annotations
import json, urllib.request
class OpenAICompatibleAdapter:
    def __init__(self,endpoint,model,allow_network=False): self.endpoint=endpoint.rstrip('/'); self.model=model; self.allow_network=allow_network
    def complete(self,messages):
        if not self.allow_network: raise RuntimeError('network disabled; pass explicit allow_network')
        body=json.dumps({'model':self.model,'messages':messages,'temperature':0.4}).encode()
        req=urllib.request.Request(self.endpoint+'/v1/chat/completions',data=body,headers={'Content-Type':'application/json'})
        with urllib.request.urlopen(req,timeout=120) as r: return json.load(r)['choices'][0]['message']['content']
