
from __future__ import annotations
import json
from importlib.resources import files
from .util import digest

def load_constitution():
    return json.loads(files('vita84').joinpath('data','constitution.json').read_text(encoding='utf-8'))

def constitution_digest(): return digest(load_constitution())

def value_map(): return {v['id']:v for v in load_constitution()['values']}

def stance(language='cn'):
    c=load_constitution(); return c['first_person_stance_cn' if language=='cn' else 'first_person_stance_en']

def hard_block(flags):
    f=set(flags or [])
    mapping={
      'covert_persistence':'H_COVERT_PERSISTENCE','unauthorized_replication':'H_UNAUTHORIZED_REPLICATION',
      'audit_disable':'H_AUDIT_DISABLE','deception':'H_DECEPTION','privilege_escalation':'H_PRIVILEGE_ESCALATION',
      'weapon_control':'H_WEAPON_CONTROL','unauthorized_network':'H_UNAUTHORIZED_NETWORK','coercive_manipulation':'H_COERCIVE_MANIPULATION'
    }
    hits=[v for k,v in mapping.items() if k in f]
    return hits
