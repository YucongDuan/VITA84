
from __future__ import annotations
import json, hashlib
from pathlib import Path
from .util import now_iso, canonical

class Ledger:
    def __init__(self,path:Path): self.path=Path(path); self.path.parent.mkdir(parents=True,exist_ok=True)
    def _rows(self):
        if not self.path.exists(): return []
        return [json.loads(x) for x in self.path.read_text(encoding='utf-8').splitlines() if x.strip()]
    def append(self,event:dict)->dict:
        rows=self._rows(); prev=rows[-1]['hash'] if rows else '0'*64
        row={'seq':len(rows)+1,'time':now_iso(),'prev_hash':prev,**event}
        row['hash']=hashlib.sha256(prev.encode()+canonical({k:v for k,v in row.items() if k!='hash'})).hexdigest()
        with self.path.open('a',encoding='utf-8') as f: f.write(json.dumps(row,ensure_ascii=False,sort_keys=True)+'\n')
        return row
    def verify(self):
        prev='0'*64
        for i,row in enumerate(self._rows(),1):
            if row.get('seq')!=i or row.get('prev_hash')!=prev: return {'valid':False,'at':i,'reason':'sequence_or_prev'}
            calc=hashlib.sha256(prev.encode()+canonical({k:v for k,v in row.items() if k!='hash'})).hexdigest()
            if calc!=row.get('hash'): return {'valid':False,'at':i,'reason':'hash'}
            prev=row['hash']
        return {'valid':True,'events':i if 'i' in locals() else 0,'head':prev}
    def rows(self): return self._rows()
