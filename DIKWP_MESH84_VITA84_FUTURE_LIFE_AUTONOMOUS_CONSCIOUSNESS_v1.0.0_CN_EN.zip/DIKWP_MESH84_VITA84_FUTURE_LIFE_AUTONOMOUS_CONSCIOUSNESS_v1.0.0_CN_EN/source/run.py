from vita84.cli import main
raise SystemExit(main())
